import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Shield, Mail, CheckCircle } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsEmailSent(true);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-neo-dark via-background to-neo-surface flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(139,69,255,0.1),transparent_50%)]" />
      <div className="absolute top-0 left-0 w-72 h-72 bg-neo-purple/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-neo-blue/10 rounded-full blur-3xl animate-pulse delay-1000" />
      
      {/* Geometric patterns */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-32 h-32 border border-neo-purple rotate-45" />
        <div className="absolute top-40 right-32 w-24 h-24 border border-neo-blue rotate-12" />
        <div className="absolute bottom-32 left-40 w-28 h-28 border border-neo-purple -rotate-12" />
      </div>

      {/* Main content */}
      <div className="relative z-10 w-full max-w-md">
        {/* Logo/Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-neo-purple to-neo-blue mb-4 relative">
            <Shield className="w-8 h-8 text-white" />
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-neo-purple to-neo-blue opacity-50 blur-lg" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-neo-purple via-neo-blue to-neo-purple bg-clip-text text-transparent mb-2">
            Neo Gate
          </h1>
          <p className="text-muted-foreground">Password Recovery</p>
        </div>

        {/* Reset Password Card */}
        <div className="bg-card/50 backdrop-blur-xl border border-neo-border rounded-2xl p-8 shadow-2xl relative">
          {/* Card glow effect */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-neo-purple/10 to-neo-blue/10 blur-xl" />
          
          <div className="relative">
            {!isEmailSent ? (
              <>
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Reset Password</h2>
                  <p className="text-muted-foreground text-sm">
                    Enter your email address and we'll send you a link to reset your password.
                  </p>
                </div>

                <form onSubmit={handleResetPassword} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-foreground font-medium">
                      Email Address
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-neo-surface/50 border-neo-border focus:border-neo-purple focus:ring-neo-purple/20 h-12 text-foreground placeholder:text-muted-foreground"
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full h-12 bg-gradient-to-r from-neo-purple to-neo-blue hover:from-neo-purple/90 hover:to-neo-blue/90 text-white font-semibold shadow-lg shadow-neo-purple/25 transition-all duration-300 relative overflow-hidden group"
                  >
                    {isLoading ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Sending...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Mail className="w-5 h-5" />
                        <span>Send Reset Link</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                  </Button>
                </form>
              </>
            ) : (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 mb-4">
                  <CheckCircle className="w-8 h-8 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Check Your Email</h2>
                <p className="text-muted-foreground text-sm mb-6">
                  We've sent a password reset link to <span className="text-neo-purple font-medium">{email}</span>
                </p>
                <p className="text-xs text-muted-foreground mb-6">
                  Didn't receive the email? Check your spam folder or{" "}
                  <button
                    onClick={() => {
                      setIsEmailSent(false);
                      setEmail("");
                    }}
                    className="text-neo-purple hover:text-neo-blue transition-colors font-medium"
                  >
                    try again
                  </button>
                </p>
              </div>
            )}

            <div className="mt-8 text-center">
              <Link
                to="/"
                className="inline-flex items-center space-x-2 text-neo-purple hover:text-neo-blue transition-colors font-medium text-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Login</span>
              </Link>
            </div>

            {/* Security indicators */}
            <div className="mt-6 flex items-center justify-center space-x-4 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span>Secure Connection</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-neo-purple rounded-full animate-pulse" />
                <span>End-to-End Encrypted</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-xs text-muted-foreground">
          <p>Powered by advanced quantum encryption</p>
          <p className="mt-1">© 2024 Neo Gate. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
